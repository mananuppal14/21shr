#ifndef GET_NEXT_LINE_H
#define GET_NEXT_LINE_H
#include "libft.h"
int get_next_line(const int fd, char **line);
int	ft_getchar(const int fd);
#ifndef GET_C_BUFF_SIZE
#define GET_C_BUFF_SIZE 1024
#endif
# ifndef BUFF_SIZE
#  define BUFF_SIZE 1024
# endif
#endif